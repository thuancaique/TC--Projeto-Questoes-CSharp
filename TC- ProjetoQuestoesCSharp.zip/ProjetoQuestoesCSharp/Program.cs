﻿using System;

namespace ProjetoQuestoesCSharp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcao;

            do
            {
                Console.Clear();
                Console.WriteLine("Selecione uma opção de 1 a 101 ou 0 para sair:");
                for (int i = 0; i <= 101; i++)
                {
                    Console.WriteLine($"{i}. Questão {i}");
                }
                Console.Write("Opção: ");

                if (int.TryParse(Console.ReadLine(), out opcao))
                {
                    switch (opcao)
                    {
                        case 0: return;
                        case 1: Questao1(); break;
                        case 2: Questao2(); break;
                        case 3: Questao3(); break;
                        case 4: Questao4(); break;
                        case 5: Questao5(); break;
                        case 6: Questao6(); break;
                        case 7: Questao7(); break;
                        case 8: Questao8(); break;
                        case 9: Questao9(); break;
                        case 10: Questao10(); break;
                        case 11: Questao11(); break;
                        case 12: Questao12(); break;
                        case 13: Questao13(); break;
                        case 14: Questao14(); break;
                        case 15: Questao15(); break;
                        case 16: Questao16(); break;
                        case 17: Questao17(); break;
                        case 18: Questao18(); break;
                        case 19: Questao19(); break;
                        case 20: Questao20(); break;
                        case 21: Questao21(); break;
                        case 22: Questao22(); break;
                        case 23: Questao23(); break;
                        case 24: Questao24(); break;
                        case 25: Questao25(); break;
                        case 26: Questao26(); break;
                        case 27: Questao27(); break;
                        case 28: Questao28(); break;
                        case 29: Questao29(); break;
                        case 30: Questao30(); break;
                        case 31: Questao31(); break;
                        case 32: Questao32(); break;
                        case 33: Questao33(); break;
                        case 34: Questao34(); break;
                        case 35: Questao35(); break;
                        case 36: Questao36(); break;
                        case 37: Questao37(); break;
                        case 38: Questao38(); break;
                        case 39: Questao39(); break;
                        case 40: Questao40(); break;
                        case 41: Questao41(); break;
                        case 42: Questao42(); break;
                        case 43: Questao43(); break;
                        case 44: Questao44(); break;
                        case 45: Questao45(); break;
                        case 46: Questao46(); break;
                        case 47: Questao47(); break;
                        case 48: Questao48(); break;
                        case 49: Questao49(); break;
                        case 50: Questao50(); break;
                        case 51: Questao51(); break;
                        case 52: Questao52(); break;
                        case 53: Questao53(); break;
                        case 54: Questao54(); break;
                        case 55: Questao55(); break;
                        case 56: Questao56(); break;
                        case 57: Questao57(); break;
                        case 58: Questao58(); break;
                        case 59: Questao59(); break;
                        case 60: Questao60(); break;
                        case 61: Questao61(); break;
                        case 62: Questao62(); break;
                        case 63: Questao63(); break;
                        case 64: Questao64(); break;
                        case 65: Questao65(); break;
                        case 66: Questao66(); break;
                        case 67: Questao67(); break;
                        case 68: Questao68(); break;
                        case 69: Questao69(); break;
                        case 70: Questao70(); break;
                        case 71: Questao71(); break;
                        case 72: Questao72(); break;
                        case 73: Questao73(); break;
                        case 74: Questao74(); break;
                        case 75: Questao75(); break;
                        case 76: Questao76(); break;
                        case 77: Questao77(); break;
                        case 78: Questao78(); break;
                        case 79: Questao79(); break;
                        case 80: Questao80(); break;
                        case 81: Questao81(); break;
                        case 82: Questao82(); break;
                        case 83: Questao83(); break;
                        case 84: Questao84(); break;
                        case 85: Questao85(); break;
                        case 86: Questao86(); break;
                        case 87: Questao87(); break;
                        case 88: Questao88(); break;
                        case 89: Questao89(); break;
                        case 90: Questao90(); break;
                        case 91: Questao91(); break;
                        case 92: Questao92(); break;
                        case 93: Questao93(); break;
                        case 94: Questao94(); break;
                        case 95: Questao95(); break;
                        case 96: Questao96(); break;
                        case 97: Questao97(); break;
                        case 98: Questao98(); break;
                        case 99: Questao99(); break;
                        case 100: Questao100(); break;
                        case 101: Questao101(); break;

                        default: Console.WriteLine("Opção inválida."); break;
                    }
                    Console.WriteLine("Pressione qualquer tecla para voltar ao menu.");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Por favor, digite um número válido.");
                    Console.ReadKey();
                }
            } while (opcao != 0);
        }

        static void Questao1()
        {
            Console.WriteLine("Questão 1: Crie uma classe Produto com propriedades Nome e Preco.");
            
        }

        static void Questao2()
        {
            Console.WriteLine("Questão 2: Instancie um objeto da classe Produto e exiba seus valores.");
          
        }

        static void Questao3()
        {
            Console.WriteLine("Questão 3: Crie um método que soma dois números inteiros e exibe o resultado.");
    
        }

        static void Questao4()
        {
            Console.WriteLine("Questão 4: Verifique se um número é par ou ímpar.");
  
        }

        static void Questao5()
        {
            Console.WriteLine("Questão 5: Converta um valor em metros para centímetros.");
     
        }

        static void Questao6()
        {
            Console.WriteLine("Questão 6: Receba a idade e verifique se a pessoa é maior de idade.");
            Console.Write("Digite a idade: ");
            int idade = int.Parse(Console.ReadLine());
            if (idade >= 18)
                Console.WriteLine("A pessoa é maior de idade.");
            else
                Console.WriteLine("A pessoa é menor de idade.");
        }

        static void Questao7()
        {
            Console.WriteLine("Questão 7: Calcule a área de um círculo com base no raio fornecido.");
            Console.Write("Digite o raio do círculo: ");
            double raio = double.Parse(Console.ReadLine());
            double area = Math.PI * Math.Pow(raio, 2);
            Console.WriteLine($"A área do círculo é: {area}");
        }

        static void Questao8()
        {
            Console.WriteLine("Questão 8: Exiba a tabuada de um número fornecido.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"{numero} x {i} = {numero * i}");
            }
        }

        static void Questao9()
        {
            Console.WriteLine("Questão 9: Some todos os números de 1 a N.");
            Console.Write("Digite um número N: ");
            int n = int.Parse(Console.ReadLine());
            int soma = 0;
            for (int i = 1; i <= n; i++)
            {
                soma += i;
            }
            Console.WriteLine($"A soma de 1 a {n} é: {soma}");
        }

        static void Questao10()
        {
            Console.WriteLine("Questão 10: Converta temperatura de Celsius para Fahrenheit.");
            Console.Write("Digite a temperatura em Celsius: ");
            double celsius = double.Parse(Console.ReadLine());
            double fahrenheit = (celsius * 9 / 5) + 32;
            Console.WriteLine($"A temperatura em Fahrenheit é: {fahrenheit}");
        }

        static void Questao11()
        {
            Console.WriteLine("Questão 11: Calcule o fatorial de um número.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            int fatorial = 1;
            for (int i = 1; i <= numero; i++)
            {
                fatorial *= i;
            }
            Console.WriteLine($"O fatorial de {numero} é: {fatorial}");
        }

        static void Questao12()
        {
            Console.WriteLine("Questão 12: Verifique se um número é primo.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            bool primo = true;

            if (numero <= 1)
            {
                primo = false;
            }
            else
            {
                for (int i = 2; i <= Math.Sqrt(numero); i++)
                {
                    if (numero % i == 0)
                    {
                        primo = false;
                        break;
                    }
                }
            }
            Console.WriteLine(primo ? $"{numero} é primo." : $"{numero} não é primo.");
        }

        static void Questao13()
        {
            Console.WriteLine("Questão 13: Calcule a média de uma lista de números.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            double soma = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                soma += double.Parse(Console.ReadLine());
            }
            double media = soma / quantidade;
            Console.WriteLine($"A média é: {media}");
        }

        static void Questao14()
        {
            Console.WriteLine("Questão 14: Exiba a sequência de Fibonacci até N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());
            int a = 0, b = 1, temp;

            Console.Write("Sequência de Fibonacci: ");
            for (int i = 0; i < n; i++)
            {
                Console.Write($"{a} ");
                temp = a;
                a = b;
                b = temp + b;
            }
            Console.WriteLine();
        }

        static void Questao15()
        {
            Console.WriteLine("Questão 15: Invertendo uma string.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            char[] caracteres = palavra.ToCharArray();
            Array.Reverse(caracteres);
            string invertida = new string(caracteres);
            Console.WriteLine($"A palavra invertida é: {invertida}");
        }

        static void Questao16()
        {
            Console.WriteLine("Questão 16: Verificar se uma palavra é um palíndromo.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            string inverso = new string(palavra.Reverse().ToArray());
            Console.WriteLine(palavra.Equals(inverso, StringComparison.OrdinalIgnoreCase) ? "É um palíndromo." : "Não é um palíndromo.");
        }

        static void Questao17()
        {
            Console.WriteLine("Questão 17: Calcule a área de um triângulo.");
            Console.Write("Digite a base: ");
            double baseTriangulo = double.Parse(Console.ReadLine());
            Console.Write("Digite a altura: ");
            double altura = double.Parse(Console.ReadLine());
            double area = (baseTriangulo * altura) / 2;
            Console.WriteLine($"A área do triângulo é: {area}");
        }

        static void Questao18()
        {
            Console.WriteLine("Questão 18: Encontre o maior de três números.");
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());
            Console.Write("Digite o terceiro número: ");
            int num3 = int.Parse(Console.ReadLine());

            int maior = Math.Max(num1, Math.Max(num2, num3));
            Console.WriteLine($"O maior número é: {maior}");
        }

        static void Questao19()
        {
            Console.WriteLine("Questão 19: Calcule a hipotenusa de um triângulo retângulo.");
            Console.Write("Digite o valor do cateto oposto: ");
            double catetoOposto = double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do cateto adjacente: ");
            double catetoAdjacente = double.Parse(Console.ReadLine());

            double hipotenusa = Math.Sqrt(Math.Pow(catetoOposto, 2) + Math.Pow(catetoAdjacente, 2));
            Console.WriteLine($"A hipotenusa é: {hipotenusa}");
        }

        static void Questao20()
        {
            Console.WriteLine("Questão 20: Converta uma palavra para letras maiúsculas.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            Console.WriteLine($"Palavra em maiúsculas: {palavra.ToUpper()}");
        }

        static void Questao21()
        {
            Console.WriteLine("Questão 21: Calcule a média de uma lista de números, ignorando os valores negativos.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            double soma = 0;
            int contagem = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                double numero = double.Parse(Console.ReadLine());
                if (numero >= 0)
                {
                    soma += numero;
                    contagem++;
                }
            }
            double media = contagem > 0 ? soma / contagem : 0;
            Console.WriteLine($"A média dos números positivos é: {media}");
        }

        static void Questao22()
        {
            Console.WriteLine("Questão 22: Verifique se um número está em uma lista de números.");
            Console.Write("Digite quantos números deseja inserir na lista: ");
            int quantidade = int.Parse(Console.ReadLine());
            List<int> numeros = new List<int>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros.Add(int.Parse(Console.ReadLine()));
            }

            Console.Write("Digite o número a ser procurado: ");
            int procurado = int.Parse(Console.ReadLine());

            Console.WriteLine(numeros.Contains(procurado) ? "O número está na lista." : "O número não está na lista.");
        }

        static void Questao23()
        {
            Console.WriteLine("Questão 23: Calcule a soma de todos os números ímpares de uma lista.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            int soma = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                int numero = int.Parse(Console.ReadLine());
                if (numero % 2 != 0)
                {
                    soma += numero;
                }
            }
            Console.WriteLine($"A soma dos números ímpares é: {soma}");
        }

        static void Questao24()
        {
            Console.WriteLine("Questão 24: Converta uma lista de palavras para letras maiúsculas.");
            Console.Write("Quantas palavras deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            List<string> palavras = new List<string>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite a palavra {i + 1}: ");
                palavras.Add(Console.ReadLine().ToUpper());
            }

            Console.WriteLine("Palavras em maiúsculas:");
            foreach (string palavra in palavras)
            {
                Console.WriteLine(palavra);
            }
        }

        static void Questao25()
        {
            Console.WriteLine("Questão 25: Exiba os primeiros N números pares.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());
            int contador = 0, numero = 0;

            while (contador < n)
            {
                if (numero % 2 == 0)
                {
                    Console.Write($"{numero} ");
                    contador++;
                }
                numero++;
            }
            Console.WriteLine();
        }

        static void Questao26()
        {
            Console.WriteLine("Questão 26: Verifique se uma palavra possui apenas letras.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            bool somenteLetras = palavra.All(char.IsLetter);

            Console.WriteLine(somenteLetras ? "A palavra contém apenas letras." : "A palavra contém outros caracteres além de letras.");
        }

        static void Questao27()
        {
            Console.WriteLine("Questão 27: Calcule a soma dos números de 1 até N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());
            int soma = n * (n + 1) / 2;
            Console.WriteLine($"A soma dos números de 1 até {n} é: {soma}");
        }

        static void Questao28()
        {
            Console.WriteLine("Questão 28: Converta uma temperatura de Celsius para Fahrenheit.");
            Console.Write("Digite a temperatura em Celsius: ");
            double celsius = double.Parse(Console.ReadLine());
            double fahrenheit = (celsius * 9 / 5) + 32;
            Console.WriteLine($"{celsius}°C em Fahrenheit é: {fahrenheit}°F");
        }

        static void Questao29()
        {
            Console.WriteLine("Questão 29: Verifique se uma lista de números está ordenada em ordem crescente.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            List<int> numeros = new List<int>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros.Add(int.Parse(Console.ReadLine()));
            }

            bool ordenada = numeros.SequenceEqual(numeros.OrderBy(n => n));
            Console.WriteLine(ordenada ? "A lista está em ordem crescente." : "A lista não está em ordem crescente.");
        }

        static void Questao30()
        {
            Console.WriteLine("Questão 30: Exiba uma contagem regressiva de um número N até 0.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = n; i >= 0; i--)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine();
        }

        static void Questao31()
        {
            Console.WriteLine("Questão 31: Verifique se um número é divisível por 3 e por 5.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());

            if (numero % 3 == 0 && numero % 5 == 0)
            {
                Console.WriteLine("O número é divisível por 3 e por 5.");
            }
            else
            {
                Console.WriteLine("O número não é divisível por 3 e por 5.");
            }
        }

        static void Questao32()
        {
            Console.WriteLine("Questão 32: Calcule o fatorial de um número.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            long fatorial = 1;

            for (int i = 1; i <= numero; i++)
            {
                fatorial *= i;
            }
            Console.WriteLine($"O fatorial de {numero} é: {fatorial}");
        }

        static void Questao33()
        {
            Console.WriteLine("Questão 33: Encontre o menor número de uma lista.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            List<int> numeros = new List<int>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros.Add(int.Parse(Console.ReadLine()));
            }

            int menor = numeros.Min();
            Console.WriteLine($"O menor número da lista é: {menor}");
        }

        static void Questao34()
        {
            Console.WriteLine("Questão 34: Exiba todos os números primos até um número N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Números primos até " + n + ":");
            for (int i = 2; i <= n; i++)
            {
                bool isPrime = true;
                for (int j = 2; j <= Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
        }

        static void Questao35()
        {
            Console.WriteLine("Questão 35: Converta um número binário para decimal.");
            Console.Write("Digite um número binário: ");
            string binario = Console.ReadLine();
            int decimalValue = Convert.ToInt32(binario, 2);
            Console.WriteLine($"O valor decimal de {binario} é: {decimalValue}");
        }

        static void Questao36()
        {
            Console.WriteLine("Questão 36: Conte o número de vogais em uma palavra.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            int contadorVogais = palavra.Count(c => "aeiouAEIOU".Contains(c));
            Console.WriteLine($"A palavra contém {contadorVogais} vogais.");
        }

        static void Questao37()
        {
            Console.WriteLine("Questão 37: Exiba os múltiplos de 4 entre 1 e um número N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine($"Múltiplos de 4 até {n}:");
            for (int i = 1; i <= n; i++)
            {
                if (i % 4 == 0)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
        }

        static void Questao38()
        {
            Console.WriteLine("Questão 38: Verifique se uma lista de números contém elementos duplicados.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            List<int> numeros = new List<int>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros.Add(int.Parse(Console.ReadLine()));
            }

            bool hasDuplicates = numeros.Count != numeros.Distinct().Count();
            Console.WriteLine(hasDuplicates ? "A lista contém duplicados." : "A lista não contém duplicados.");
        }

        static void Questao39()
        {
            Console.WriteLine("Questão 39: Calcule a média de uma lista de números.");
            Console.Write("Quantos números deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            List<double> numeros = new List<double>();

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros.Add(double.Parse(Console.ReadLine()));
            }

            double media = numeros.Average();
            Console.WriteLine($"A média dos números é: {media}");
        }

        static void Questao40()
        {
            Console.WriteLine("Questão 40: Exiba uma contagem progressiva de 1 até um número N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine();
        }


        static void Questao41()
        {
            Console.WriteLine("Questão 41: Converta uma temperatura de Celsius para Fahrenheit.");
            Console.Write("Digite a temperatura em Celsius: ");
            double celsius = double.Parse(Console.ReadLine());
            double fahrenheit = (celsius * 9 / 5) + 32;
            Console.WriteLine($"A temperatura em Fahrenheit é: {fahrenheit}");
        }

        static void Questao42()
        {
            Console.WriteLine("Questão 42: Converta uma temperatura de Fahrenheit para Celsius.");
            Console.Write("Digite a temperatura em Fahrenheit: ");
            double fahrenheit = double.Parse(Console.ReadLine());
            double celsius = (fahrenheit - 32) * 5 / 9;
            Console.WriteLine($"A temperatura em Celsius é: {celsius}");
        }

        static void Questao43()
        {
            Console.WriteLine("Questão 43: Calcule a área de um triângulo dado a base e a altura.");
            Console.Write("Digite a base do triângulo: ");
            double baseTriangulo = double.Parse(Console.ReadLine());
            Console.Write("Digite a altura do triângulo: ");
            double alturaTriangulo = double.Parse(Console.ReadLine());
            double area = (baseTriangulo * alturaTriangulo) / 2;
            Console.WriteLine($"A área do triângulo é: {area}");
        }

        static void Questao44()
        {
            Console.WriteLine("Questão 44: Verifique se um número está entre 10 e 20.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());

            if (numero >= 10 && numero <= 20)
            {
                Console.WriteLine("O número está entre 10 e 20.");
            }
            else
            {
                Console.WriteLine("O número não está entre 10 e 20.");
            }
        }

        static void Questao45()
        {
            Console.WriteLine("Questão 45: Calcule a média ponderada de três notas com pesos diferentes.");
            Console.Write("Digite a primeira nota: ");
            double nota1 = double.Parse(Console.ReadLine());
            Console.Write("Digite o peso da primeira nota: ");
            double peso1 = double.Parse(Console.ReadLine());

            Console.Write("Digite a segunda nota: ");
            double nota2 = double.Parse(Console.ReadLine());
            Console.Write("Digite o peso da segunda nota: ");
            double peso2 = double.Parse(Console.ReadLine());

            Console.Write("Digite a terceira nota: ");
            double nota3 = double.Parse(Console.ReadLine());
            Console.Write("Digite o peso da terceira nota: ");
            double peso3 = double.Parse(Console.ReadLine());

            double mediaPonderada = ((nota1 * peso1) + (nota2 * peso2) + (nota3 * peso3)) / (peso1 + peso2 + peso3);
            Console.WriteLine($"A média ponderada é: {mediaPonderada}");
        }

        static void Questao46()
        {
            Console.WriteLine("Questão 46: Exiba os números ímpares entre 1 e um número N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Números ímpares:");
            for (int i = 1; i <= n; i++)
            {
                if (i % 2 != 0)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
        }

        static void Questao47()
        {
            Console.WriteLine("Questão 47: Calcule o perímetro de um retângulo dado o comprimento e a largura.");
            Console.Write("Digite o comprimento: ");
            double comprimento = double.Parse(Console.ReadLine());
            Console.Write("Digite a largura: ");
            double largura = double.Parse(Console.ReadLine());

            double perimetro = 2 * (comprimento + largura);
            Console.WriteLine($"O perímetro do retângulo é: {perimetro}");
        }

        static void Questao48()
        {
            Console.WriteLine("Questão 48: Calcule a área de um círculo dado o raio.");
            Console.Write("Digite o raio do círculo: ");
            double raio = double.Parse(Console.ReadLine());
            double area = Math.PI * Math.Pow(raio, 2);
            Console.WriteLine($"A área do círculo é: {area}");
        }

        static void Questao49()
        {
            Console.WriteLine("Questão 49: Encontre o maior valor em um array.");
            Console.Write("Quantos elementos deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] numeros = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            int maior = numeros.Max();
            Console.WriteLine($"O maior valor do array é: {maior}");
        }

        static void Questao50()
        {
            Console.WriteLine("Questão 50: Verifique se um ano é bissexto.");
            Console.Write("Digite um ano: ");
            int ano = int.Parse(Console.ReadLine());

            if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0))
            {
                Console.WriteLine($"{ano} é um ano bissexto.");
            }
            else
            {
                Console.WriteLine($"{ano} não é um ano bissexto.");
            }
        }

        static void Questao51()
        {
            Console.WriteLine("Questão 51: Verifique se uma string é um palíndromo.");
            Console.Write("Digite uma palavra: ");
            string palavra = Console.ReadLine();
            string reverso = new string(palavra.Reverse().ToArray());

            if (palavra.Equals(reverso, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("A palavra é um palíndromo.");
            }
            else
            {
                Console.WriteLine("A palavra não é um palíndromo.");
            }
        }

        static void Questao52()
        {
            Console.WriteLine("Questão 52: Calcule a média aritmética de um array de inteiros.");
            Console.Write("Quantos elementos deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] numeros = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            double media = numeros.Average();
            Console.WriteLine($"A média aritmética dos elementos é: {media}");
        }

        static void Questao53()
        {
            Console.WriteLine("Questão 53: Encontre o menor valor em um array.");
            Console.Write("Quantos elementos deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] numeros = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            int menor = numeros.Min();
            Console.WriteLine($"O menor valor do array é: {menor}");
        }

        static void Questao54()
        {
            Console.WriteLine("Questão 54: Calcule o fatorial de um número.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            int fatorial = 1;

            for (int i = 1; i <= numero; i++)
            {
                fatorial *= i;
            }
            Console.WriteLine($"O fatorial de {numero} é: {fatorial}");
        }

        static void Questao55()
        {
            Console.WriteLine("Questão 55: Exiba os números pares entre 1 e um número N.");
            Console.Write("Digite o valor de N: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Números pares:");
            for (int i = 1; i <= n; i++)
            {
                if (i % 2 == 0)
                {
                    Console.Write($"{i} ");
                }
            }
            Console.WriteLine();
        }

        static void Questao56()
        {
            Console.WriteLine("Questão 56: Converta uma string para letras maiúsculas.");
            Console.Write("Digite uma string: ");
            string input = Console.ReadLine();
            Console.WriteLine($"String em maiúsculas: {input.ToUpper()}");
        }

        static void Questao57()
        {
            Console.WriteLine("Questão 57: Converta uma string para letras minúsculas.");
            Console.Write("Digite uma string: ");
            string input = Console.ReadLine();
            Console.WriteLine($"String em minúsculas: {input.ToLower()}");
        }

        static void Questao58()
        {
            Console.WriteLine("Questão 58: Calcule a potência de um número dado a base e o expoente.");
            Console.Write("Digite a base: ");
            double baseNum = double.Parse(Console.ReadLine());
            Console.Write("Digite o expoente: ");
            double expoente = double.Parse(Console.ReadLine());

            double potencia = Math.Pow(baseNum, expoente);
            Console.WriteLine($"O resultado é: {potencia}");
        }

        static void Questao59()
        {
            Console.WriteLine("Questão 59: Conte o número de caracteres em uma string.");
            Console.Write("Digite uma string: ");
            string input = Console.ReadLine();
            int comprimento = input.Length;

            Console.WriteLine($"A string tem {comprimento} caracteres.");
        }

        static void Questao60()
        {
            Console.WriteLine("Questão 60: Calcule a soma dos números em um array.");
            Console.Write("Quantos elementos deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] numeros = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            int soma = numeros.Sum();
            Console.WriteLine($"A soma dos elementos do array é: {soma}");
        }

        static void Questao61()
        {
            Console.WriteLine("Questão 61: Verifique se uma matriz é quadrada.");
            Console.Write("Digite o número de linhas da matriz: ");
            int linhas = int.Parse(Console.ReadLine());
            Console.Write("Digite o número de colunas da matriz: ");
            int colunas = int.Parse(Console.ReadLine());

            if (linhas == colunas)
            {
                Console.WriteLine("A matriz é quadrada.");
            }
            else
            {
                Console.WriteLine("A matriz não é quadrada.");
            }
        }

        static void Questao62()
        {
            Console.WriteLine("Questão 62: Verifique se uma matriz é simétrica.");
            Console.Write("Digite a ordem da matriz quadrada (n x n): ");
            int ordem = int.Parse(Console.ReadLine());
            int[,] matriz = new int[ordem, ordem];
            bool simetrica = true;

            for (int i = 0; i < ordem; i++)
            {
                for (int j = 0; j < ordem; j++)
                {
                    Console.Write($"Digite o elemento [{i},{j}]: ");
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            for (int i = 0; i < ordem; i++)
            {
                for (int j = 0; j < ordem; j++)
                {
                    if (matriz[i, j] != matriz[j, i])
                    {
                        simetrica = false;
                        break;
                    }
                }
            }

            if (simetrica)
            {
                Console.WriteLine("A matriz é simétrica.");
            }
            else
            {
                Console.WriteLine("A matriz não é simétrica.");
            }
        }

        static void Questao63()
        {
            Console.WriteLine("Questão 63: Calcule o determinante de uma matriz 2x2.");
            int[,] matriz = new int[2, 2];

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.Write($"Digite o elemento [{i},{j}]: ");
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            int determinante = matriz[0, 0] * matriz[1, 1] - matriz[0, 1] * matriz[1, 0];
            Console.WriteLine($"O determinante da matriz é: {determinante}");
        }

        static void Questao64()
        {
            Console.WriteLine("Questão 64: Calcule o produto escalar entre dois vetores.");
            Console.Write("Digite o número de elementos dos vetores: ");
            int tamanho = int.Parse(Console.ReadLine());
            int[] vetor1 = new int[tamanho];
            int[] vetor2 = new int[tamanho];
            int produtoEscalar = 0;

            for (int i = 0; i < tamanho; i++)
            {
                Console.Write($"Digite o elemento {i + 1} do primeiro vetor: ");
                vetor1[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < tamanho; i++)
            {
                Console.Write($"Digite o elemento {i + 1} do segundo vetor: ");
                vetor2[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < tamanho; i++)
            {
                produtoEscalar += vetor1[i] * vetor2[i];
            }

            Console.WriteLine($"O produto escalar dos vetores é: {produtoEscalar}");
        }

        static void Questao65()
        {
            Console.WriteLine("Questão 65: Calcule a média ponderada de um conjunto de números.");
            Console.Write("Quantos números deseja inserir? ");
            int n = int.Parse(Console.ReadLine());
            int[] numeros = new int[n];
            int[] pesos = new int[n];
            int somaPesos = 0;
            int somaPonderada = 0;

            for (int i = 0; i < n; i++)
            {
                Console.Write($"Digite o número {i + 1}: ");
                numeros[i] = int.Parse(Console.ReadLine());
                Console.Write($"Digite o peso do número {i + 1}: ");
                pesos[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
            {
                somaPonderada += numeros[i] * pesos[i];
                somaPesos += pesos[i];
            }

            double mediaPonderada = (double)somaPonderada / somaPesos;
            Console.WriteLine($"A média ponderada é: {mediaPonderada}");
        }

        static void Questao66()
        {
            Console.WriteLine("Questão 66: Conte a quantidade de palavras em uma frase.");
            Console.Write("Digite uma frase: ");
            string frase = Console.ReadLine();
            int quantidadePalavras = frase.Split(' ').Length;

            Console.WriteLine($"A frase tem {quantidadePalavras} palavras.");
        }

        static void Questao67()
        {
            Console.WriteLine("Questão 67: Substitua todos os espaços de uma string por hifens.");
            Console.Write("Digite uma string: ");
            string input = Console.ReadLine();
            string resultado = input.Replace(" ", "-");

            Console.WriteLine($"String modificada: {resultado}");
        }

        static void Questao68()
        {
            Console.WriteLine("Questão 68: Converta uma temperatura em Celsius para Fahrenheit.");
            Console.Write("Digite a temperatura em Celsius: ");
            double celsius = double.Parse(Console.ReadLine());

            double fahrenheit = (celsius * 9 / 5) + 32;
            Console.WriteLine($"A temperatura em Fahrenheit é: {fahrenheit}");
        }

        static void Questao69()
        {
            Console.WriteLine("Questão 69: Converta uma temperatura em Fahrenheit para Celsius.");
            Console.Write("Digite a temperatura em Fahrenheit: ");
            double fahrenheit = double.Parse(Console.ReadLine());

            double celsius = (fahrenheit - 32) * 5 / 9;
            Console.WriteLine($"A temperatura em Celsius é: {celsius}");
        }

        static void Questao70()
        {
            Console.WriteLine("Questão 70: Verifique se um número está em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("Digite o número a ser verificado: ");
            int numero = int.Parse(Console.ReadLine());

            if (lista.Contains(numero))
            {
                Console.WriteLine("O número está na lista.");
            }
            else
            {
                Console.WriteLine("O número não está na lista.");
            }
        }

        static void Questao71()
        {
            Console.WriteLine("Questão 71: Verifique se um número é primo.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            bool primo = true;

            if (numero <= 1)
                primo = false;
            else
            {
                for (int i = 2; i <= Math.Sqrt(numero); i++)
                {
                    if (numero % i == 0)
                    {
                        primo = false;
                        break;
                    }
                }
            }

            if (primo)
                Console.WriteLine("O número é primo.");
            else
                Console.WriteLine("O número não é primo.");
        }

        static void Questao72()
        {
            Console.WriteLine("Questão 72: Calcule o máximo divisor comum (MDC) entre dois números.");
            Console.Write("Digite o primeiro número: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int b = int.Parse(Console.ReadLine());

            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }

            Console.WriteLine($"O MDC é: {a}");
        }

        static void Questao73()
        {
            Console.WriteLine("Questão 73: Calcule o mínimo múltiplo comum (MMC) entre dois números.");
            Console.Write("Digite o primeiro número: ");
            int x = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int y = int.Parse(Console.ReadLine());
            int mdc = x, n = y;

            while (n != 0)
            {
                int temp = n;
                n = mdc % n;
                mdc = temp;
            }

            int mmc = Math.Abs(x * y) / mdc;
            Console.WriteLine($"O MMC é: {mmc}");
        }

        static void Questao74()
        {
            Console.WriteLine("Questão 74: Encontre o maior elemento em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            int maior = lista.Max();
            Console.WriteLine($"O maior elemento da lista é: {maior}");
        }

        static void Questao75()
        {
            Console.WriteLine("Questão 75: Encontre o menor elemento em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            int menor = lista.Min();
            Console.WriteLine($"O menor elemento da lista é: {menor}");
        }

        static void Questao76()
        {
            Console.WriteLine("Questão 76: Inverta a ordem dos elementos de uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Reverse(lista);
            Console.WriteLine("A lista invertida é: " + string.Join(", ", lista));
        }

        static void Questao77()
        {
            Console.WriteLine("Questão 77: Conte os números pares em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];
            int contadorPares = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
                if (lista[i] % 2 == 0)
                    contadorPares++;
            }

            Console.WriteLine($"A lista contém {contadorPares} números pares.");
        }

        static void Questao78()
        {
            Console.WriteLine("Questão 78: Conte os números ímpares em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];
            int contadorImpares = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
                if (lista[i] % 2 != 0)
                    contadorImpares++;
            }

            Console.WriteLine($"A lista contém {contadorImpares} números ímpares.");
        }

        static void Questao79()
        {
            Console.WriteLine("Questão 79: Calcule a média de uma lista de números.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];
            int soma = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
                soma += lista[i];
            }

            double media = (double)soma / quantidade;
            Console.WriteLine($"A média da lista é: {media}");
        }

        static void Questao80()
        {
            Console.WriteLine("Questão 80: Ordene uma lista de números em ordem crescente.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(lista);
            Console.WriteLine("Lista ordenada em ordem crescente: " + string.Join(", ", lista));
        }

        static void Questao81()
        {
            Console.WriteLine("Questão 81: Ordene uma lista de números em ordem decrescente.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(lista);
            Array.Reverse(lista);
            Console.WriteLine("Lista ordenada em ordem decrescente: " + string.Join(", ", lista));
        }

        static void Questao82()
        {
            Console.WriteLine("Questão 82: Calcule o desvio padrão de uma lista de números.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            double[] lista = new double[quantidade];
            double soma = 0, media;

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = double.Parse(Console.ReadLine());
                soma += lista[i];
            }

            media = soma / quantidade;
            double somaQuadrados = lista.Sum(x => Math.Pow(x - media, 2));
            double desvioPadrao = Math.Sqrt(somaQuadrados / quantidade);

            Console.WriteLine($"O desvio padrão é: {desvioPadrao}");
        }

        static void Questao83()
        {
            Console.WriteLine("Questão 83: Converta um número decimal para binário.");
            Console.Write("Digite um número decimal: ");
            int numero = int.Parse(Console.ReadLine());
            string binario = Convert.ToString(numero, 2);

            Console.WriteLine($"O número {numero} em binário é: {binario}");
        }

        static void Questao84()
        {
            Console.WriteLine("Questão 84: Converta um número binário para decimal.");
            Console.Write("Digite um número binário: ");
            string binario = Console.ReadLine();
            int decimalNum = Convert.ToInt32(binario, 2);

            Console.WriteLine($"O número binário {binario} em decimal é: {decimalNum}");
        }

        static void Questao85()
        {
            Console.WriteLine("Questão 85: Encontre a mediana de uma lista de números.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(lista);
            double mediana;
            if (quantidade % 2 == 0)
                mediana = (lista[quantidade / 2 - 1] + lista[quantidade / 2]) / 2.0;
            else
                mediana = lista[quantidade / 2];

            Console.WriteLine($"A mediana da lista é: {mediana}");
        }

        static void Questao86()
        {
            Console.WriteLine("Questão 86: Verifique se uma string é um palíndromo.");
            Console.Write("Digite uma string: ");
            string texto = Console.ReadLine().ToLower().Replace(" ", "");
            string reverso = new string(texto.Reverse().ToArray());

            if (texto == reverso)
                Console.WriteLine("A string é um palíndromo.");
            else
                Console.WriteLine("A string não é um palíndromo.");
        }

        static void Questao87()
        {
            Console.WriteLine("Questão 87: Encontre o segundo maior número em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(lista);
            int segundoMaior = lista[quantidade - 2];
            Console.WriteLine($"O segundo maior número é: {segundoMaior}");
        }

        static void Questao88()
        {
            Console.WriteLine("Questão 88: Encontre o segundo menor número em uma lista.");
            Console.Write("Quantos elementos deseja inserir na lista? ");
            int quantidade = int.Parse(Console.ReadLine());
            int[] lista = new int[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite o elemento {i + 1}: ");
                lista[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(lista);
            int segundoMenor = lista[1];
            Console.WriteLine($"O segundo menor número é: {segundoMenor}");
        }

        static void Questao89()
        {
            Console.WriteLine("Questão 89: Encontre a soma dos dígitos de um número.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            int soma = 0;

            while (numero > 0)
            {
                soma += numero % 10;
                numero /= 10;
            }

            Console.WriteLine($"A soma dos dígitos é: {soma}");
        }

        static void Questao90()
        {
            Console.WriteLine("Questão 90: Verifique se dois números são amigos (par de números amigáveis).");
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            int somaDivisores1 = 0, somaDivisores2 = 0;
            for (int i = 1; i <= num1 / 2; i++)
                if (num1 % i == 0)
                    somaDivisores1 += i;

            for (int i = 1; i <= num2 / 2; i++)
                if (num2 % i == 0)
                    somaDivisores2 += i;

            if (somaDivisores1 == num2 && somaDivisores2 == num1)
                Console.WriteLine("Os números são amigos.");
            else
                Console.WriteLine("Os números não são amigos.");
        }



        static void Questao91()
        {
            Console.WriteLine("Questão 91: Conte o número de vogais em uma string.");
            Console.Write("Digite uma string: ");
            string texto = Console.ReadLine();
            int contador = 0;

            foreach (char c in texto.ToLower())
            {
                if ("aeiou".Contains(c))
                    contador++;
            }

            Console.WriteLine($"O número de vogais na string é: {contador}");
        }

        static void Questao92()
        {
            Console.WriteLine("Questão 92: Verifique se uma string é um anagrama de outra.");
            Console.Write("Digite a primeira string: ");
            string texto1 = Console.ReadLine().ToLower().Replace(" ", "");
            Console.Write("Digite a segunda string: ");
            string texto2 = Console.ReadLine().ToLower().Replace(" ", "");

            var contador1 = texto1.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());
            var contador2 = texto2.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());

            if (contador1.Count == contador2.Count && !contador1.Except(contador2).Any())
                Console.WriteLine("As strings são anagramas.");
            else
                Console.WriteLine("As strings não são anagramas.");
        }

        static void Questao93()
        {
            Console.WriteLine("Questão 93: Verifique se um número é primo.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            bool ehPrimo = true;

            if (numero < 2) ehPrimo = false;
            else
            {
                for (int i = 2; i <= Math.Sqrt(numero); i++)
                {
                    if (numero % i == 0)
                    {
                        ehPrimo = false;
                        break;
                    }
                }
            }

            if (ehPrimo)
                Console.WriteLine($"{numero} é um número primo.");
            else
                Console.WriteLine($"{numero} não é um número primo.");
        }

        static void Questao94()
        {
            Console.WriteLine("Questão 94: Encontre a soma dos números de Fibonacci até um limite.");
            Console.Write("Digite o limite: ");
            int limite = int.Parse(Console.ReadLine());
            int a = 0, b = 1, soma = 0;

            while (b <= limite)
            {
                soma += b;
                int temp = b;
                b += a;
                a = temp;
            }

            Console.WriteLine($"A soma dos números de Fibonacci até {limite} é: {soma}");
        }

        static void Questao95()
        {
            Console.WriteLine("Questão 95: Encontre o máximo divisor comum (MDC) de dois números.");
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            while (num2 != 0)
            {
                int temp = num2;
                num2 = num1 % num2;
                num1 = temp;
            }

            Console.WriteLine($"O máximo divisor comum é: {num1}");
        }

        static void Questao96()
        {
            Console.WriteLine("Questão 96: Encontre o mínimo múltiplo comum (MMC) de dois números.");
            Console.Write("Digite o primeiro número: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            int num2 = int.Parse(Console.ReadLine());

            int mdc = num1;
            while (num2 != 0)
            {
                int temp = num2;
                num2 = mdc % num2;
                mdc = temp;
            }

            int mmc = (num1 * num2) / mdc;
            Console.WriteLine($"O mínimo múltiplo comum é: {mmc}");
        }

        static void Questao97()
        {
            Console.WriteLine("Questão 97: Verifique se um número é um quadrado perfeito.");
            Console.Write("Digite um número: ");
            int numero = int.Parse(Console.ReadLine());
            double raiz = Math.Sqrt(numero);

            if (raiz % 1 == 0)
                Console.WriteLine($"{numero} é um quadrado perfeito.");
            else
                Console.WriteLine($"{numero} não é um quadrado perfeito.");
        }

        static void Questao98()
        {
            Console.WriteLine("Questão 98: Crie um array de strings e ordene em ordem alfabética.");
            Console.Write("Quantas strings deseja inserir? ");
            int quantidade = int.Parse(Console.ReadLine());
            string[] lista = new string[quantidade];

            for (int i = 0; i < quantidade; i++)
            {
                Console.Write($"Digite a string {i + 1}: ");
                lista[i] = Console.ReadLine();
            }

            Array.Sort(lista);
            Console.WriteLine("Strings ordenadas em ordem alfabética: " + string.Join(", ", lista));
        }

        static void Questao99()
        {
            Console.WriteLine("Questão 99: Calcule a potência de um número.");
            Console.Write("Digite a base: ");
            double baseNum = double.Parse(Console.ReadLine());
            Console.Write("Digite o expoente: ");
            double expoente = double.Parse(Console.ReadLine());

            double resultado = Math.Pow(baseNum, expoente);
            Console.WriteLine($"{baseNum} elevado a {expoente} é: {resultado}");
        }

        static void Questao100()
        {
            Console.WriteLine("Questão 100: Encontre a soma dos números pares de 1 a N.");
            Console.Write("Digite um número N: ");
            int n = int.Parse(Console.ReadLine());
            int soma = 0;

            for (int i = 2; i <= n; i += 2)
                soma += i;

            Console.WriteLine($"A soma dos números pares de 1 a {n} é: {soma}");
        }
        static void Questao101()
        {
            string palavraSecreta = "desenvolvimento"; 
            HashSet<char> letrasAdvinhadas = new HashSet<char>();
            int tentativasRestantes = 5;

            Console.WriteLine("Bem-vindo ao jogo da Forca!");
            Console.WriteLine("Tente adivinhar a palavra secreta.");

            while (tentativasRestantes > 0)
            {
                ExibirPalavra(palavraSecreta, letrasAdvinhadas);
                Console.WriteLine($"Tentativas restantes: {tentativasRestantes}");
                Console.Write("Digite uma letra: ");
                char letra = Console.ReadLine()[0];

                if (letrasAdvinhadas.Contains(letra))
                {
                    Console.WriteLine("Você já tentou essa letra. Tente outra.");
                    continue;
                }

                letrasAdvinhadas.Add(letra);

                if (!palavraSecreta.Contains(letra))
                {
                    tentativasRestantes--;
                    Console.WriteLine("Letra incorreta!");
                }

                if (PalavraAdivinhada(palavraSecreta, letrasAdvinhadas))
                {
                    Console.WriteLine($"Parabéns! Você adivinhou a palavra: {palavraSecreta}");
                    return;
                }
            }

            Console.WriteLine($"Você perdeu! A palavra era: {palavraSecreta}");
        }

        static void ExibirPalavra(string palavra, HashSet<char> letrasAdvinhadas)
        {
            foreach (char letra in palavra)
            {
                if (letrasAdvinhadas.Contains(letra))
                    Console.Write(letra + " ");
                else
                    Console.Write("_ ");
            }
            Console.WriteLine();
        }

        static bool PalavraAdivinhada(string palavra, HashSet<char> letrasAdvinhadas)
        {
            foreach (char letra in palavra)
            {
                if (!letrasAdvinhadas.Contains(letra))
                    return false;
            }
            return true;
        }


    }
}

